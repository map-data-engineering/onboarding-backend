# Workshop Application Portal

Two self-contained HTML files. No build step, no framework, no database.

- **`apply.html`** — the applicant-facing application and timed knowledge check
- **`panel.html`** — the staff scoring and shortlisting tool (runs entirely in your browser)

Open either file directly in a browser to try it, or drop both into any static host
(Vercel, GitHub Pages, Netlify, an S3 bucket). `panel.html` should sit behind whatever
access control your host offers — it contains no secrets, but you don't want applicants
reading the scoring rules.

---

## Deploying

```
application-portal/
├── apply.html      →  yoursite.com/apply.html
├── panel.html      →  yoursite.com/panel.html   (restrict access)
└── README.md
```

Vercel: drag the folder onto the dashboard, or `vercel --prod` from inside it.

### Wiring up submissions

Open `apply.html` and edit the `CONFIG` block near the top of the `<script>`:

```js
const CONFIG = {
  SUBMIT_ENDPOINT: "",            // ← paste your endpoint here
  CONTACT_EMAIL: "cmyalla@ihi.or.tz",
  DEADLINE: "Friday 28 August 2026",
  QUOTA: { R:3, SPATIAL:5, STATS:3, BAYES:2, HEALTH:1 }
};
```

`SUBMIT_ENDPOINT` receives a JSON POST per application. Anything that accepts JSON works —
[Formspree](https://formspree.io), [Basin](https://usebasin.com), a Google Apps Script web
app, or your own API. **If you leave it empty**, each applicant downloads a `.json` file and
is asked to email it to you; the panel loads those files directly. That is a perfectly
workable fallback for a single round, and it needs no backend at all.

Whichever route you take, the panel accepts both: drop `.json` files onto it, or paste a
JSON array from your form backend.

---

## What the instrument measures

The design assumption is 500 applicants for 25 seats. At 20:1 the job is not to identify the
best 25 by machine — it is to rank everyone automatically so humans read 60 applications
instead of 500.

**Composite score, out of 100:**

| Component | Points | What it measures | Gameable? |
|---|---|---|---|
| Knowledge check | 45 | 14 timed scenario questions, drawn at random | Hard — see below |
| Honesty check | 20 | Overclaiming grid: 8 real R functions, 4 invented | No — self-marking |
| Readiness & relevance | 20 | R frequency, GLM experience, data in hand, and **whether real code was supplied** | Partly |
| Likely impact | 15 | Will train colleagues, produces analyses others use, has real spatial data | Yes — self-report |

No supervisor endorsement is collected — it added nothing to ranking, since every applicant
supplies one.

The impact block is self-reported and most applicants will max it. That is intentional: it
contributes little to ranking, and exists mainly so applicants see that the panel cares about
more than a quiz score. Ranking is driven by the first three components.

### Why the knowledge check resists lookup

- **One question at a time, per-question countdown, no back-navigation, single attempt.**
- **Every question is a novel scenario** with specific numbers, asking for a consequence or a
  next action. There is no searchable phrase that returns the answer, because the situation
  does not exist anywhere online.
- **Distractors are the common misconceptions**, not filler, so elimination doesn't work.
- **Each applicant gets a different draw** from a 24-question bank with options shuffled —
  roughly 37,800 distinct question sets, so answers cannot circulate within an institution.
- **Timers are tuned to reading load** (35s for short recall, 50s for scenarios; ~10 minutes
  total). Long enough to be fair to non-native English readers, far too short to search,
  read and evaluate an unfamiliar result.

Nothing tests INLA or inlabru. The published prerequisites are R plus regression and GLMs,
and that is all the quiz covers.

### Why the honesty check is the most valuable single block

Applicants tick whether they have used each of twelve R functions. Four —
`st_reproject`, `read.shapefile`, `spatial_join_df`, `raster_scale2` — do not exist. They
are deliberately plausible: `st_reproject` is what `st_transform` arguably should have been
called, and `read.shapefile` is what people assume exists.

Claiming one costs **−3**; each genuine function is **+1**. Verifying twelve names by search
is economically irrational under the clock, and the applicant doesn't know which are fake.

It is the only block that measures honesty rather than knowledge — and honesty about your own
level predicts coping in a fast practical better than knowledge does, because people who
bluff don't ask for help when they fall behind.

---

## Running the selection

1. **Load applications.** Open `panel.html`, drop in the `.json` files or paste your array.
   Duplicate submissions are removed automatically, keeping the first per email address.
2. **Check the header advice.** If the median quiz score is 11+ the questions are too easy and
   are not discriminating; the panel tells you so.
3. **Set your floors** — seats, minimum women, minimum Tanzania-based, maximum per
   institution, travel certainty and waitlist size — and click **Build shortlist**. Floors are
   satisfied first, then remaining seats fill on merit. The status pills turn red if a floor
   cannot be met.
4. **Read the written answers** for everyone near the cut line. Click any row.
5. **Export CSV** for the full ranking or the shortlist alone.

### No participant funding — how the portal handles it

There is no travel, accommodation or subsistence support. The portal is explicit about this
in three places rather than burying it:

1. **A warning box on the first screen**, before anyone invests fifteen minutes.
2. **An eligibility question** asking how travel will be covered — institution agreed, self
   funded, likely but unconfirmed, or could not attend without support.
3. **An honest exit** for anyone selecting the last option: they are told plainly that no
   funding exists and that this reflects the budget, not their application. Set
   `FUNDING_GATE: false` in `apply.html` if you would rather let them apply and decide case
   by case; they are then flagged `UNFUNDED` in the panel.

Telling someone "no" in ten seconds is kinder than a fifteen-minute application you cannot
honour, and it keeps the applicant pool honest.

**Travel certainty in the shortlist builder** has three modes:

| Mode | Behaviour |
|---|---|
| Prefer confirmed *(default)* | Fills every seat from confirmed applicants first, then uses unconfirmed ones only if seats remain |
| Confirmed only | Excludes unconfirmed applicants entirely |
| Ignore | Ranks purely on merit |

On a simulated 500-applicant pool where 40% had unconfirmed travel, "prefer" cut unconfirmed
participants in the final 25 from **12 to zero** at a cost of **3.2 points of median score** —
a trivial price for materially fewer no-shows. "Confirmed only" gave an identical result here,
so the softer setting is the sensible default: it costs nothing when confirmed applicants are
plentiful, and degrades gracefully when they are not.

**Also build a waitlist** (default 10) and require acceptances to be confirmed within five
days. The waitlist is exported in the CSV with its own column.

### Applying floors early matters

Apply diversity floors when cutting to the shortlist, not at the final 25. A shortlist of 60
that is lopsided by gender or institution is very hard to fix afterwards, and at 20:1 you can
afford to be wrong at the margins on individual technical scores — two slightly weaker
participants will not damage the workshop, but a homogeneous room will.

### Flags

| Flag | Meaning | Suggested action |
|---|---|---|
| `BLUFF` | Claimed a function that does not exist | Exclude (toggle in the builder) |
| `NO-CODE` | Supplied no real R code sample | Strongest predictor of struggling — check personally |
| `INCONSISTENT` | Self-rated Advanced, scored under 40% | Read the whole application |
| `RUSHED` | Used under 20% of allotted time | Likely random clicking |
| `TIMEOUTS` | More than 3 questions unanswered | Soft signal only — may be a careful reader |
| `TRAVEL-UNCONFIRMED` | Travel funding likely but not yet confirmed | Fill from confirmed applicants first |
| `UNFUNDED` | Cannot attend without support (only if the gate is off) | Do not offer a seat |
| `NO-LAPTOP` | Cannot bring a laptop | Resolve before offering a seat |

The panel **recomputes every score from the raw answers** rather than trusting the value
submitted by the browser, so a tampered submission is scored correctly regardless.

---

## Editing questions

The bank lives in `apply.html` under `const BANK`. Each entry:

```js
{id:"s1", cat:"SPATIAL", secs:45,
 stem:"Question text shown to the applicant",
 code:"optional <- code_block()",           // omit if not needed
 opts:["A","B","C","D"], ans:2}             // ans = index of the correct option
```

`ans` refers to the order **as written here** — display order is shuffled per applicant, so
you never need to worry about spreading correct answers across positions. Add questions
freely; the draw quotas in `CONFIG.QUOTA` control how many of each category each applicant
sees. Keep at least two spare questions per category so the draw actually varies.

If you edit the fake function names in `CLAIM_FAKE`, **make the same edit in `panel.html`** —
both files carry the list so the panel can re-score independently.

---

## Contact details collected

- **WhatsApp number, with country code.** Validation requires a leading `+`, so a local
  number like `0712345678` is rejected with a message explaining why — it cannot be dialled
  from outside the country. Spaces, hyphens and brackets are all accepted. The CSV export
  writes the number with a leading apostrophe so Excel doesn't strip the `+`.
- **Country of residence and nationality are dropdowns** covering all 195 UN member states,
  with Tanzania and its neighbours pinned in a group at the top. This prevents "Tanzania",
  "tanzania" and "United Republic of Tanzania" appearing as three values in one export, and
  it makes the Tanzania-based diversity floor reliable, since the panel matches on an exact
  string.

## Branding

Both pages follow the Malaria Atlas Project style tile:

| Colour | Hex | Used for |
|---|---|---|
| Gold | `#EBBC40` | Primary buttons, header rule, progress bar, active step, selected option |
| Black | `#111010` | Headings, body text, table headers |
| Charcoal | `#383838` | Secondary surfaces, button hover, completed steps |
| Warm grey | `#9E9C97` | Rules and borders only |
| Light grey | `#F3F3F3` | Page background, code blocks, zebra striping |

Fonts: **Lato** for headings, buttons and labels; **Nunito Sans** for body text. Both load
from Google Fonts with system-sans fallbacks, so the pages degrade gracefully on a poor
connection.

**Two deliberate deviations, for accessibility:**

- **Gold is never used for text on white** — it gives 1.8:1 contrast, far below the 4.5:1
  needed. It appears as a fill with near-black text on top (10.7:1), and as rules and
  accents. Warm grey `#9E9C97` is likewise confined to borders; muted text uses a darker
  tint of the same warm hue at 5.2:1.
- **Semantic red and green** sit outside the tile but are needed for correct/incorrect and
  met/unmet states. Both are muted toward the palette's warmth rather than used at full
  saturation.

Every text/background pair in both files passes WCAG AA. Add your logo files to the header
in each page — the style tile specifies master, reversed and mono variants.

## Privacy

`panel.html` processes everything locally in the browser; no applicant data is uploaded
anywhere by the panel. Applicant submissions go only to the endpoint you configure. The
application form collects gender and nationality for diversity monitoring — add your
institution's data-protection wording to the details page before going live, and state how
long you will retain applications.

---

## Known limitations, stated plainly

- **No unsupervised online test is chatbot-proof.** A determined applicant can photograph a
  question and get an answer. The timer, the randomised draw, the overclaiming block and the
  code sample together make it more effort than it is worth, but they do not make it
  impossible. The code sample at Stage 2 is where fabrication usually shows.
- **The impact block is self-reported** and near-universally maxed. Treat it as a tiebreaker.
- **A single-attempt guard uses browser storage**, so it is defeated by a different browser or
  private window. It deters casual retries, nothing more. If you need a hard guarantee, issue
  one-time application links from your backend.
