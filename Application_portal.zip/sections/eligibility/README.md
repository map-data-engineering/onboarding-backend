# Eligibility gate

Four questions that end an application early when a place could not be honoured.

## Why gate at all

The point is kindness as much as filtering. Someone who cannot fund their own travel should
find that out in ten seconds, not after fifteen minutes of forms and a timed test, and not in
a rejection email three weeks later. Gating early also keeps the pool honest — seats do not
get offered to people who were never able to travel, which at 25 seats matters a great deal.

## The questions

| # | Question | Behaviour |
|---|---|---|
| 1 | Can you attend in person for all four days? | **Blocks** on "No" |
| 2 | Do you have a laptop on which you can install software (R, RStudio, INLA)? | Advisory — flags `NO-LAPTOP` |
| 3 | Do you have access to spatial data you could analyse? | **Blocks** on "No" |
| 4 | Travel and accommodation are not funded. How will yours be covered? | **Blocks** on "could not attend without support"; flags `TRAVEL-UNCONFIRMED` |

**Question 2 deliberately does not block.** "I am not sure" is usually an IT-permissions
question that resolves well before the workshop, and blocking on it would turn a solvable
admin problem into a rejection. It raises a flag instead, so you can follow up.

**Question 4 is the one to think about.** A hard gate will disproportionately exclude junior
and lower-resourced applicants, which pulls against most diversity goals. Set
`fundingGate: false` to let them apply anyway, flagged `UNFUNDED`, and make the call yourself
case by case. There is no neutral option here — decide deliberately rather than by default.

## Install

Copy the folder. No dependencies, no build step.

```
eligibility/
├── eligibility.js   the module
├── index.html       standalone demo — open it directly
└── README.md
```

## Use

```html
<div id="host"></div>

<script type="module">
  import { mountEligibility } from "./eligibility.js";

  const elig = mountEligibility(document.getElementById("host"), {
    contactEmail: "cmyalla@ihi.or.tz",
    fundingGate: true,
    onBlocked: reason => {
      // The host element has already been replaced with the exit message.
      hideProgressBar();
      analytics.track("application_blocked", { reason });
    }
  });

  document.querySelector("#next").onclick = () => {
    const r = elig.validate();
    if (!r.ok) return;                    // blocked, or a question unanswered
    application.eligibility = elig.value();
    application.flags.push(...r.flags);
    goToNextStep();
  };
</script>
```

## API

### `mountEligibility(host, opts?)`

| Option | Default | Meaning |
|---|---|---|
| `contactEmail` | `""` | Shown on exit screens so blocked applicants can join a mailing list |
| `fundingGate` | `true` | `false` lets unfunded applicants continue, flagged `UNFUNDED` |
| `showHeading` | `true` | Render the built-in `<h2>` and intro |
| `onBlocked` | — | `(reason, message)` callback when an answer ends the application |

Returns `{ value(), validate(), flags(), isBlocked(), renderExit() }`.

- **`validate()`** → `{ ok: true, flags }` · `{ ok: false, message }` if unanswered ·
  `{ ok: false, blocked: true, reason }` if an answer ends the application. In the blocked
  case the host element is **replaced** with the exit message.
- **`value()`** → `{ attend, laptop, data, funding }`
- **`flags()`** → `["TRAVEL-UNCONFIRMED"]`, `["NO-LAPTOP"]`, `["UNFUNDED"]`, or `[]`
- **`isBlocked(v?)`** → `"attendance"` · `"data"` · `"funding"` · `null`
- **`renderExit(reason)`** → render an exit screen manually

## Flags

| Flag | Meaning | Suggested handling |
|---|---|---|
| `TRAVEL-UNCONFIRMED` | Funding likely but not confirmed | Fill seats from confirmed applicants first, then these |
| `UNFUNDED` | Cannot attend without support (gate off only) | Do not offer a seat |
| `NO-LAPTOP` | No laptop, or unsure | Resolve before confirming the place |

In our shortlisting we ran a "prefer confirmed travel" pass: fill every seat from confirmed
applicants first, then use unconfirmed ones only if seats remain. On a simulated pool where
40% were unconfirmed, that cut unconfirmed participants in the final 25 from 12 to zero for
about 3 points of median score — a cheap trade against no-shows.

## Editing the questions

`QUESTIONS` is an exported array. Each entry:

```js
{
  id: "attend",                    // key in value()
  label: "Can you attend…?",
  options: ["Yes…", "No"],
  blocking: ["No"],                // answers that end the application
  blockReason: "attendance",       // key into BLOCK_MESSAGES
  flagMap: { "Answer": "FLAG" },   // optional, per-answer flags
  flagUnless: "Yes", flag: "X",    // optional, flag anything that isn't this
  note: "Shown under the field"    // optional
}
```

`BLOCK_MESSAGES` holds the exit copy. It is written to be plain and non-judgemental — an
applicant should understand the block is about your constraints, not their worth. If you edit
it, keep that tone; people talk to each other, and a curt rejection costs you next year's
applicants.

## Styling

MAP palette (gold `#EBBC40`, black `#111010`), Lato headings, Nunito Sans body. CSS is injected
once and scoped under `.elg`, so it will not leak. Override the `--e-*` custom properties to
restyle. Contrast meets WCAG AA; unanswered fields are marked with colour *and* an error
message, not colour alone.

## Licence

MIT.
