/**
 * Eligibility gate — four questions that end an application early when a place
 * could not be honoured.
 * ---------------------------------------------------------------------------
 * The point is kindness as much as filtering. Telling someone "no" in ten seconds
 * is better than letting them complete a fifteen-minute application you were never
 * going to be able to accept. It also keeps the applicant pool honest, so seats
 * are not offered to people who cannot travel.
 *
 * Two questions are hard stops by default (attendance, funding), one is advisory
 * (laptop), one shapes ranking (access to data).
 *
 * Zero dependencies. Framework agnostic. MAP brand styling included.
 *
 * Usage:
 *   import { mountEligibility } from "./eligibility.js";
 *   const el = mountEligibility(document.getElementById("host"), {
 *     contactEmail: "cmyalla@ihi.or.tz",
 *     onBlocked: reason => showExitScreen(reason)
 *   });
 *   el.validate();  // {ok, blocked?, reason?}
 *   el.value();     // {attend, laptop, data, funding}
 *   el.flags();     // ["TRAVEL-UNCONFIRMED", "NO-LAPTOP", …]
 *
 * @license MIT
 */

export const QUESTIONS = [
  {
    id: "attend",
    label: "Can you attend in person for all four days of the workshop?",
    options: ["Yes, all four days", "Only part of the period", "No"],
    // Answers that end the application.
    blocking: ["No"],
    blockReason: "attendance"
  },
  {
    id: "laptop",
    label: "Do you have a laptop on which you can install software (R, RStudio, INLA)?",
    options: ["Yes", "No", "I am not sure"],
    // Advisory rather than blocking: "not sure" is usually an IT-permissions
    // question that can be resolved before September, and blocking here would
    // exclude people unnecessarily.
    blocking: [],
    flagUnless: "Yes",
    flag: "NO-LAPTOP"
  },
  {
    id: "data",
    label: "Do you have access to spatial data you could analyse?",
    options: [
      "Yes, I work with it now",
      "Not yet, but I expect to within six months",
      "No"
    ],
    blocking: ["No"],
    blockReason: "data"
  },
  {
    id: "funding",
    label: "Travel and accommodation are not funded by the workshop. How will yours be covered?",
    options: [
      "My institution has agreed to cover it",
      "I will cover it myself",
      "Likely covered, but not yet confirmed",
      "I could not attend without financial support"
    ],
    blocking: ["I could not attend without financial support"],
    blockReason: "funding",
    flagMap: {
      "Likely covered, but not yet confirmed": "TRAVEL-UNCONFIRMED",
      "I could not attend without financial support": "UNFUNDED"
    },
    note: `Please answer this one accurately rather than optimistically. A place offered to
      someone who cannot travel is a place lost to another applicant.`
  }
];

/* Exit messages. Written to be plain and non-judgemental: the applicant should
   understand this is about our constraints, not their worth. */
export const BLOCK_MESSAGES = {
  attendance: {
    title: "Thank you for your interest",
    body: `<p>This is a four-day in-person course in which each day builds on the last, so we
      are not able to offer places to people who cannot attend the full period.</p>`
  },
  data: {
    title: "Thank you for your interest",
    body: `<p>The workshop is built around participants applying the methods to their own
      spatial data. Without data to work with, most of the practical sessions would not be
      usable for you.</p>`
  },
  funding: {
    title: "We are sorry — we cannot support travel costs",
    body: `<p>We have no funding for participant travel, accommodation or subsistence, and no
      way to create any before the workshop. We would rather tell you plainly now than have
      you spend fifteen minutes on an application we could not honour.</p>
      <p>This is a limitation of our budget, not a judgement on your application.</p>`
  }
};

const CSS = `
.elg{--e-gold:#EBBC40;--e-gold-tint:#fdf6e6;--e-black:#111010;--e-charcoal:#383838;
  --e-line:#e0deda;--e-light:#F3F3F3;--e-grey:#6f6d68;--e-bad:#96331f;
  --e-head:"Lato",-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;
  --e-body:"Nunito Sans",-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;
  font-family:var(--e-body);color:var(--e-black);line-height:1.6}
.elg h2{font-family:var(--e-head);font-size:22px;margin:0 0 6px}
.elg .e-lead{color:var(--e-grey);margin:0 0 18px}
.elg .e-q{margin:0 0 18px}
.elg label.e-label{display:block;font-family:var(--e-head);font-size:13.5px;font-weight:700;
  margin:0 0 6px}
.elg label.e-label .req{color:var(--e-bad);font-weight:400}
.elg select{width:100%;padding:10px 12px;border:1px solid #cbc9c4;border-radius:8px;
  font:inherit;font-size:15px;background:#fff;font-family:var(--e-body)}
.elg select:focus{outline:none;border-color:var(--e-gold);
  box-shadow:0 0 0 3px rgba(235,188,64,.28)}
.elg select.e-missing{border-color:var(--e-bad);background:#fdf3f0}
.elg .e-note{background:var(--e-light);border-left:4px solid var(--e-charcoal);
  padding:11px 14px;border-radius:0 8px 8px 0;font-size:13.5px;margin:8px 0 0}
.elg .e-err{color:var(--e-bad);font-size:13.5px;font-weight:700;margin-top:12px}
.elg .e-exit h2{margin-bottom:10px}
.elg .e-exit p{margin:0 0 12px}
`;

function injectCss(){
  if (document.getElementById("elg-styles")) return;
  const s = document.createElement("style");
  s.id = "elg-styles";
  s.textContent = CSS;
  document.head.appendChild(s);
}

const esc = s => String(s ?? "").replace(/[&<>"']/g,
  c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));

/**
 * Render the eligibility questions.
 * @param {HTMLElement} host
 * @param {object} [opts]
 * @param {string}  [opts.contactEmail]        Shown on exit screens.
 * @param {boolean} [opts.fundingGate=true]    False = let unfunded applicants continue,
 *                                             flagged UNFUNDED, and decide case by case.
 * @param {boolean} [opts.showHeading=true]
 * @param {Function}[opts.onBlocked]           Called with (reason, {title, body}) when an
 *                                             answer ends the application.
 * @returns {{value, validate, flags, isBlocked, renderExit}}
 */
export function mountEligibility(host, opts = {}) {
  injectCss();
  const contact = opts.contactEmail || "";
  const fundingGate = opts.fundingGate !== false;

  const heading = opts.showHeading === false ? "" : `
    <h2>Eligibility</h2>
    <p class="e-lead">Four practical questions. Please answer accurately — a place you cannot
    take up is a place another applicant could have used.</p>`;

  host.classList.add("elg");
  host.innerHTML = `${heading}
    ${QUESTIONS.map(q => `<div class="e-q">
      <label class="e-label" for="e_${q.id}">${esc(q.label)} <span class="req">*</span></label>
      <select id="e_${q.id}" data-q="${q.id}">
        <option value="">Choose…</option>
        ${q.options.map(o => `<option value="${esc(o)}">${esc(o)}</option>`).join("")}
      </select>
      ${q.note ? `<p class="e-note">${q.note}</p>` : ""}
    </div>`).join("")}
    <div class="e-err" id="e-err" hidden></div>`;

  host.addEventListener("change", e => e.target.classList.remove("e-missing"));

  const value = () => {
    const out = {};
    QUESTIONS.forEach(q => { out[q.id] = host.querySelector(`#e_${q.id}`).value; });
    return out;
  };

  const isBlocked = (v = value()) => {
    for (const q of QUESTIONS) {
      if (!q.blocking || !q.blocking.length) continue;
      if (q.blockReason === "funding" && !fundingGate) continue;
      if (q.blocking.includes(v[q.id])) return q.blockReason;
    }
    return null;
  };

  const flags = (v = value()) => {
    const out = [];
    QUESTIONS.forEach(q => {
      if (q.flagMap && q.flagMap[v[q.id]]) out.push(q.flagMap[v[q.id]]);
      if (q.flagUnless && v[q.id] && v[q.id] !== q.flagUnless) out.push(q.flag);
    });
    return out;
  };

  const renderExit = reason => {
    const m = BLOCK_MESSAGES[reason];
    if (!m) return;
    host.innerHTML = `<div class="e-exit">
      <h2>${m.title}</h2>
      ${m.body}
      <p>We expect to run further courses. ${contact
        ? `Please write to <strong>${esc(contact)}</strong> to be added to the mailing list
           so we can tell you when the next one opens.`
        : ""}</p>
    </div>`;
  };

  const validate = () => {
    const v = value();
    const err = host.querySelector("#e-err");
    const missing = QUESTIONS.filter(q => !v[q.id]);
    host.querySelectorAll("select").forEach(s => s.classList.remove("e-missing"));

    if (missing.length) {
      missing.forEach(q => host.querySelector(`#e_${q.id}`).classList.add("e-missing"));
      err.hidden = false;
      err.textContent = "Please answer all four questions.";
      host.querySelector(".e-missing").focus();
      return { ok: false, message: err.textContent };
    }
    err.hidden = true;

    const reason = isBlocked(v);
    if (reason) {
      renderExit(reason);
      if (typeof opts.onBlocked === "function") opts.onBlocked(reason, BLOCK_MESSAGES[reason]);
      return { ok: false, blocked: true, reason };
    }
    return { ok: true, flags: flags(v) };
  };

  return { value, validate, flags, isBlocked, renderExit };
}
