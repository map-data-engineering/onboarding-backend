/**
 * Honesty check — an overclaiming grid for screening workshop applicants.
 * ---------------------------------------------------------------------------
 * Applicants say whether they have used each of twelve R functions. Four of the
 * twelve do not exist. Claiming one is scored heavily negative.
 *
 * Why this works better than a knowledge question:
 *   - It measures honesty rather than knowledge, and honesty about your own level
 *     predicts coping in a fast-paced practical better than knowledge does.
 *     People who bluff do not ask for help when they fall behind.
 *   - Verifying twelve function names by search is not worth it under a clock, and
 *     the applicant cannot tell which are the fakes.
 *   - It marks itself. No human reads anything.
 *
 * The fake names are deliberately plausible: `st_reproject` is arguably what
 * `st_transform` should have been called, and `read.shapefile` is what people
 * assume exists. Only someone who has actually written the code knows.
 *
 * Zero dependencies. Framework agnostic. MAP brand styling included.
 *
 * Usage:
 *   import { mountHonestyCheck } from "./honesty-check.js";
 *   const hc = mountHonestyCheck(document.getElementById("host"));
 *   hc.validate();  // {ok:false, message:"…"} until every row is answered
 *   hc.value();     // {"read.csv":"used", "st_reproject":"no", …}
 *   hc.score();     // {points, max, normalised, bluffCount, flags:["BLUFF"]}
 *
 * @license MIT
 */

/* --------------------------------------------------------------------------
   The function lists. Edit freely, but keep two rules:
     1. Fakes must look like something that plausibly exists.
     2. If you change FAKE, change it everywhere you re-score (e.g. a staff panel
        that recomputes scores from the raw answers).
   -------------------------------------------------------------------------- */
export const REAL_FUNCTIONS = [
  "read.csv", "group_by", "ggplot", "glm",
  "st_read", "st_transform", "rast", "predict"
];

export const FAKE_FUNCTIONS = [
  "st_reproject", "read.shapefile", "spatial_join_df", "raster_scale2"
];

/* Scoring. A fake claimed as "used" or even "heard of" costs 3; each genuine
   function used earns 1. Score is floored at zero so nobody goes negative. */
export const SCORING = { realUsed: +1, fakeClaimed: -3 };

const CSS = `
.hc{--hc-gold:#EBBC40;--hc-gold-tint:#fdf6e6;--hc-black:#111010;--hc-charcoal:#383838;
  --hc-line:#e0deda;--hc-light:#F3F3F3;--hc-grey:#6f6d68;--hc-bad:#96331f;
  --hc-head:"Lato",-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;
  --hc-body:"Nunito Sans",-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;
  font-family:var(--hc-body);color:var(--hc-black);line-height:1.6}
.hc h2{font-family:var(--hc-head);font-size:22px;margin:0 0 6px;color:var(--hc-black)}
.hc .hc-lead{color:var(--hc-grey);margin:0 0 16px}
.hc .hc-warn{background:var(--hc-gold-tint);border-left:4px solid var(--hc-gold);
  padding:12px 14px;border-radius:0 8px 8px 0;font-size:14px;margin:16px 0}
.hc table{width:100%;border-collapse:collapse;font-size:14.5px;margin-top:14px}
.hc th{background:var(--hc-black);color:#fff;font-family:var(--hc-head);font-weight:700;
  padding:9px 8px;font-size:12.5px;text-align:center}
.hc th:first-child{text-align:left}
.hc td{border-bottom:1px solid var(--hc-line);padding:9px 8px;text-align:center}
.hc td:first-child{text-align:left;font-family:ui-monospace,Consolas,monospace;font-size:14px}
.hc tr:nth-child(even) td{background:var(--hc-light)}
.hc tr.hc-todo td{background:#fdf3f0}
.hc input[type=radio]{accent-color:var(--hc-charcoal);width:17px;height:17px;cursor:pointer}
.hc label.hc-cell{display:block;padding:4px;cursor:pointer}
.hc .hc-err{color:var(--hc-bad);font-size:13.5px;font-weight:700;margin-top:12px}
@media(max-width:560px){.hc th,.hc td{font-size:12px;padding:7px 4px}}
`;

function injectCss(){
  if (document.getElementById("hc-styles")) return;
  const s = document.createElement("style");
  s.id = "hc-styles";
  s.textContent = CSS;
  document.head.appendChild(s);
}

const shuffle = a => {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

const esc = s => String(s ?? "").replace(/[&<>"']/g,
  c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));

/**
 * Render the honesty check into a host element.
 * @param {HTMLElement} host
 * @param {object} [opts]
 * @param {boolean} [opts.showHeading=true]  Render the h2 and intro text.
 * @param {string[]} [opts.real]             Override the real function list.
 * @param {string[]} [opts.fake]             Override the fake function list.
 * @returns {{value:Function, validate:Function, score:Function, rows:string[]}}
 */
export function mountHonestyCheck(host, opts = {}) {
  injectCss();
  const real = opts.real || REAL_FUNCTIONS;
  const fake = opts.fake || FAKE_FUNCTIONS;
  // Shuffled so the fakes are not clustered and the order differs per applicant.
  const rows = shuffle(real.concat(fake));

  const heading = opts.showHeading === false ? "" : `
    <h2>Honesty check</h2>
    <p class="hc-lead">Which of these R functions have you used <em>yourself</em>?</p>
    <div class="hc-warn"><strong>Please read.</strong> Some of the names below are not real
    R functions. Claiming one costs you more than admitting you do not know it. We are not
    expecting anyone to know all of them — an accurate picture helps us support you better.</div>`;

  host.classList.add("hc");
  host.innerHTML = `${heading}
    <table>
      <thead><tr>
        <th scope="col">Function</th>
        <th scope="col">Used it myself</th>
        <th scope="col">Heard of it</th>
        <th scope="col">Don't know it</th>
      </tr></thead>
      <tbody>
        ${rows.map((f, i) => `<tr data-row="${i}">
          <td>${esc(f)}()</td>
          ${["used","heard","no"].map(v => `<td><label class="hc-cell">
            <input type="radio" name="hc_${i}" value="${v}"
              aria-label="${esc(f)} — ${v === "used" ? "used it myself"
                : v === "heard" ? "heard of it" : "don't know it"}">
          </label></td>`).join("")}
        </tr>`).join("")}
      </tbody>
    </table>
    <div class="hc-err" id="hc-err" hidden></div>`;

  // Clear the "unanswered" highlight as soon as a row is answered.
  host.addEventListener("change", e => {
    const tr = e.target.closest("tr");
    if (tr) tr.classList.remove("hc-todo");
  });

  const value = () => {
    const out = {};
    rows.forEach((f, i) => {
      const checked = host.querySelector(`input[name="hc_${i}"]:checked`);
      if (checked) out[f] = checked.value;
    });
    return out;
  };

  const validate = () => {
    const answers = value();
    const missing = rows.filter(f => !(f in answers));
    const err = host.querySelector("#hc-err");
    host.querySelectorAll("tr[data-row]").forEach(tr => tr.classList.remove("hc-todo"));
    if (missing.length) {
      missing.forEach(f => {
        const tr = host.querySelector(`tr[data-row="${rows.indexOf(f)}"]`);
        if (tr) tr.classList.add("hc-todo");
      });
      err.hidden = false;
      err.textContent = `Please answer for every function — ${missing.length} still to go.`;
      const first = host.querySelector("tr.hc-todo");
      if (first) first.scrollIntoView({ behavior: "smooth", block: "center" });
      return { ok: false, message: err.textContent, missing };
    }
    err.hidden = true;
    return { ok: true };
  };

  return { value, validate, score: () => scoreHonestyCheck(value(), { real, fake }), rows };
}

/**
 * Score a set of answers. Pure function — safe to re-run server-side or in a
 * staff panel, so you never have to trust a score computed in the applicant's
 * browser.
 * @param {Record<string,"used"|"heard"|"no">} answers
 * @returns {{points:number, max:number, normalised:number, bluffCount:number, flags:string[]}}
 */
export function scoreHonestyCheck(answers, opts = {}) {
  const real = opts.real || REAL_FUNCTIONS;
  const fake = opts.fake || FAKE_FUNCTIONS;
  let points = 0, bluffCount = 0;

  for (const [fn, v] of Object.entries(answers || {})) {
    if (fake.includes(fn)) {
      // "Heard of it" is also a claim about something that does not exist.
      if (v === "used" || v === "heard") {
        points += SCORING.fakeClaimed;
        if (v === "used") bluffCount++;
      }
    } else if (real.includes(fn) && v === "used") {
      points += SCORING.realUsed;
    }
  }

  const max = real.length;
  const clamped = Math.max(0, Math.min(points, max));
  return {
    points,
    max,
    normalised: max ? +(clamped / max).toFixed(3) : 0,  // 0–1, use as a weight
    bluffCount,
    flags: bluffCount > 0 ? ["BLUFF"] : []
  };
}
