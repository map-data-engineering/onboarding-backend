# Honesty check

A self-marking overclaiming grid for screening applicants to a technical workshop.

Applicants say whether they have used each of twelve R functions. **Four of the twelve do not
exist.** Claiming one costs three points; each genuine function used earns one.

![no screenshot — open `index.html` in a browser to see it](#)

## Why bother

At 20 applicants per seat you need something that ranks people without a human reading
anything, and that a search engine cannot answer for them. This block does both.

- **It measures honesty, not knowledge.** That matters more than it sounds: honesty about your
  own level predicts who copes in a fast-paced practical better than knowledge does, because
  people who bluff don't ask for help when they fall behind.
- **Looking it up isn't worth it.** Verifying twelve function names costs several minutes for
  at most eight points, and the applicant can't tell which four are the fakes.
- **It marks itself.** No reviewer time at all.

The fakes are deliberately plausible. `st_reproject` is arguably what `st_transform` should
have been called; `read.shapefile` is what people assume exists. Only someone who has actually
written the code knows the difference.

## Install

Copy the folder. No dependencies, no build step.

```
honesty-check/
├── honesty-check.js   the module
├── index.html         standalone demo — open it directly
└── README.md
```

## Use

```html
<div id="host"></div>

<script type="module">
  import { mountHonestyCheck } from "./honesty-check.js";

  const hc = mountHonestyCheck(document.getElementById("host"));

  document.querySelector("#next").onclick = () => {
    const check = hc.validate();      // highlights unanswered rows, scrolls to the first
    if (!check.ok) return;

    saveToApplication({
      claims: hc.value(),             // raw answers — always store these
      honesty: hc.score()             // convenience, but recompute server-side
    });
  };
</script>
```

Using a bundler or a framework, `import` it the same way. There is no global; it is an ES
module. If you need a classic `<script>`, delete the `export` keywords and the functions
become globals.

## API

### `mountHonestyCheck(host, opts?)`

| Option | Default | Meaning |
|---|---|---|
| `showHeading` | `true` | Render the built-in `<h2>` and instruction box. Set `false` if your page supplies its own. |
| `real` | see below | Override the real function list. |
| `fake` | see below | Override the fake function list. |

Returns `{ value(), validate(), score(), rows }`.

- **`value()`** → `{ "read.csv": "used", "st_reproject": "no", … }`
- **`validate()`** → `{ ok: true }`, or `{ ok: false, message, missing }` and highlights the
  unanswered rows in the table
- **`score()`** → see below
- **`rows`** → the shuffled function order this applicant saw

### `scoreHonestyCheck(answers, opts?)`

A pure function, exported separately so you can **recompute the score from the raw answers**
in a staff panel or on a server, rather than trusting a number produced in the applicant's
browser.

```js
{
  points: 5,          // raw: +1 per real function used, −3 per fake claimed
  max: 8,             // number of real functions
  normalised: 0.625,  // points clamped to 0…max, divided by max — use as a weight
  bluffCount: 0,      // fakes claimed as "used it myself"
  flags: []           // ["BLUFF"] if bluffCount > 0
}
```

Multiply `normalised` by whatever this section is worth in your scheme. In the workshop portal
it carries 20 of 100 points:

```js
const honestyPoints = scoreHonestyCheck(app.claims).normalised * 20;
```

### Handling `BLUFF`

Someone who claims a function that does not exist has told you something specific and
verifiable about how they represent themselves. Our default is to exclude them, but the flag
is returned rather than enforced so you can decide. If you keep them, at least read their
application by hand.

## Editing the lists

```js
export const REAL_FUNCTIONS = ["read.csv","group_by","ggplot","glm",
                               "st_read","st_transform","rast","predict"];
export const FAKE_FUNCTIONS = ["st_reproject","read.shapefile",
                               "spatial_join_df","raster_scale2"];
```

Two rules when editing:

1. **A fake must look like something that plausibly exists.** An obviously silly name
   (`do_the_analysis`) tests nothing — everybody gets it right and the item carries no
   information.
2. **If you change `FAKE_FUNCTIONS`, change it everywhere you re-score.** Any staff panel
   holding its own copy of the list will silently mis-score otherwise.

Adapting to another language is straightforward — the technique is not R-specific. For Python
you might pair `geopandas.read_file` and `rasterio.open` against `gpd.reproject_crs` and
`pandas.read_shapefile`.

## Accessibility and layout

Every radio has an `aria-label` naming both the function and the answer, since the visual
column headings are not announced per cell. The table reflows at 560px for phones — a
meaningful share of applicants in the region will apply on a phone. Contrast meets WCAG AA
throughout.

Styling follows the Malaria Atlas Project palette (gold `#EBBC40`, black `#111010`) with Lato
headings and Nunito Sans body. The CSS is injected once, scoped under `.hc`, so it will not
leak into the rest of your page. Restyle by overriding the `--hc-*` custom properties.

## Limitations, stated plainly

- **A determined applicant with a second device can defeat it.** Nothing unsupervised is
  chatbot-proof. This raises the cost of bluffing; it does not eliminate it. Pair it with a
  request for a real code sample, which is where fabrication usually shows.
- **Do not use it alone.** It is one signal among several. Someone honest and inexperienced
  scores low here and may still be exactly who the workshop is for.

## Licence

MIT. Attribution appreciated but not required.
