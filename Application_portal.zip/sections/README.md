# Application portal sections

Three drop-in modules from a workshop application portal. Each is self-contained — copy the
folder, import one function, done. No dependencies, no build step, no framework.

| Section | What it does | Open the demo |
|---|---|---|
| [**before-you-begin**](before-you-begin/) | Preparation screen listing what to have ready before starting | `before-you-begin/index.html` |
| [**eligibility**](eligibility/) | Four questions that end an application early when a place could not be honoured | `eligibility/index.html` |
| [**honesty-check**](honesty-check/) | Self-marking overclaiming grid — four of the twelve R functions do not exist | `honesty-check/index.html` |

Every folder has its own README with the full API. Every `index.html` runs standalone: open it
directly in a browser, no server needed.

## The problem these solve

Screening 500 applicants for 25 seats, with no budget for reviewer time. The constraint that
shapes everything: **anything with a single correct answer that exists in the literature can be
found in twenty seconds**, so a conventional knowledge quiz ranks nobody.

Each module attacks a different part of that.

- **before-you-begin** raises the quality of what you receive, by making sure people arrive
  with their material drafted rather than improvising into a text box.
- **eligibility** removes applicants a seat could never have been offered to — early, so
  nobody wastes fifteen minutes, and so seats do not go to people who cannot travel.
- **honesty-check** ranks on something that cannot be looked up, because the answer is about
  the applicant rather than about R.

## Common conventions

All three modules follow the same shape, so they compose:

```js
const section = mountSomething(hostElement, options);

section.validate();   // {ok:true} | {ok:false, message} — also highlights the problem
section.value();      // plain object, safe to serialise into your application record
```

Where a module scores, the scoring function is **exported separately as a pure function** so
you can recompute from the raw answers in a staff panel or on a server. Never trust a score
computed in the applicant's browser.

```js
import { scoreHonestyCheck } from "./honesty-check/honesty-check.js";
const points = scoreHonestyCheck(storedApplication.claims).normalised * 20;
```

Each module injects its own CSS once, scoped under a class prefix (`.byb`, `.elg`, `.hc`), so
nothing leaks into your page. Restyle by overriding the custom properties.

## Styling

Malaria Atlas Project palette — gold `#EBBC40`, black `#111010`, charcoal `#383838`, warm grey
`#9E9C97`, light grey `#F3F3F3` — with Lato headings and Nunito Sans body, both from Google
Fonts with system fallbacks.

Two deliberate deviations, both for accessibility: gold never carries text on white (1.8:1
contrast, far below the 4.5:1 minimum) so it appears as a fill with near-black on top; and warm
grey is confined to borders, with muted text using a darker tint of the same hue. Every
text/background pair passes WCAG AA.

## Browser support

Modern evergreen browsers. Uses ES modules, `optional chaining` and `??`. If you need a classic
`<script>` build, delete the `export` keywords and the functions become globals — there is
nothing else to change.

## What these do not do

- **They are not chatbot-proof.** Nothing unsupervised is. They raise the cost of gaming an
  application; they do not eliminate it. Pair them with a request for a real code sample,
  which is where fabrication usually shows.
- **They do not select anyone.** They produce signals and flags. A human still decides, and
  should — especially near the cut line.

## Licence

MIT. Attribution appreciated but not required.
