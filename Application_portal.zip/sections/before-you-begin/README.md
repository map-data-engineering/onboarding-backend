# Before you begin

A preparation screen shown before an application starts, listing what the applicant needs to
have ready.

## Why bother

Applicants who start unprepared do one of two things: abandon halfway through, or paste
something thin into the written boxes because they did not know the question was coming.
Neither tells you anything useful about them. One screen up front prevents both.

The confirmation tickboxes are not legal cover. They exist because ticking *"my CV is saved as
a PDF, no more than 2 pages and under 4 MB"* makes people go and check — which is the whole
point.

## What it asks for

| # | Item | Requirement |
|---|---|---|
| 1 | A 2-page CV | PDF, maximum 4 MB, ready to upload from this device |
| 2 | Your background | Maximum 300 words |
| 3 | Your motivation | Maximum 300 words |

All three are configurable. The start button stays disabled until every box is ticked.

There is also a **Print this list** button. A meaningful share of applicants will read this on
a phone and draft their answers elsewhere; giving them something to work from offline is worth
the two lines of code.

## Install

Copy the folder. No dependencies, no build step.

```
before-you-begin/
├── before-you-begin.js   the module
├── index.html            standalone demo — open it directly
└── README.md
```

## Use

```html
<div id="host"></div>

<script type="module">
  import { mountBeforeYouBegin } from "./before-you-begin.js";

  mountBeforeYouBegin(document.getElementById("host"), {
    deadline: "Friday 28 August 2026",
    duration: "about 15 minutes",
    costNote: `<strong>There is no fee to attend</strong>, but we cannot fund travel,
      accommodation or subsistence.`,
    onStart: () => goToStep(1)
  });
</script>
```

## API

### `mountBeforeYouBegin(host, opts?)`

| Option | Default | Meaning |
|---|---|---|
| `onStart` | — | `(confirmed) => {}` — called when the applicant begins |
| `requirements` | the three above | Override the list entirely |
| `requireConfirmation` | `true` | `false` removes the tickboxes and the gate |
| `deadline` | — | Shown in the closing line |
| `duration` | `"about 15 minutes"` | Set this honestly; a surprise timed section annoys people |
| `costNote` | — | HTML. Funding statement, rendered as a highlighted callout |
| `startLabel` | `"Start my application"` | Button text |

Returns `{ confirmed(), validate() }`.

- **`confirmed()`** → `{ cv: true, background: true, motivation: true }`
- **`validate()`** → `{ ok: true }` or `{ ok: false, message }`, marking unticked rows

### Custom requirements

```js
requirements: [
  {
    id: "cv",                                    // key in confirmed()
    title: "A 2-page CV",
    detail: "PDF format, maximum 4 MB.",
    confirm: "My CV is saved as a PDF, under 4 MB"   // tickbox wording
  }
]
```

Keep `confirm` specific and checkable. "I have read the requirements" makes people tick
without thinking; "My CV is saved as a PDF, no more than 2 pages and under 4 MB" makes them
open the file.

## Enforcing the limits later

This screen only *tells* applicants the limits. Enforce them where the fields actually are:

```js
// CV upload
if (file.type !== "application/pdf")  reject("PDF only");
if (file.size > 4 * 1024 * 1024)      reject("Maximum 4 MB");

// Word limits — count words, not characters
const words = text.trim().split(/\s+/).filter(Boolean).length;
if (words > 300) reject(`${words} words — maximum is 300`);
```

Show a live word counter rather than truncating silently. Someone who wrote 340 words should
be told which 40 to cut, not have their last paragraph disappear.

**Page count cannot be checked in the browser** without a PDF library. If two pages matters to
you, either accept it on trust — the tickbox does most of the work — or check at review time.
We would not add a PDF parser for this.

## Styling

MAP palette (gold `#EBBC40`, black `#111010`), Lato headings, Nunito Sans body. CSS is injected
once and scoped under `.byb`, so it will not leak into your page. Override the `--b-*` custom
properties to restyle. The demo includes a print stylesheet that strips the page chrome.

## Licence

MIT.
