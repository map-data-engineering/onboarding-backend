/**
 * Before you begin — a preparation screen shown before the application starts.
 * ---------------------------------------------------------------------------
 * Applicants who start unprepared abandon halfway, or paste something thin into
 * the written boxes because they did not know they were coming. Listing the
 * requirements up front costs a screen and saves both.
 *
 * The confirmation checkboxes are not legal cover. They exist because ticking
 * "my CV is ready as a PDF" makes people go and check, which is the entire point.
 *
 * Zero dependencies. Framework agnostic. MAP brand styling included.
 *
 * Usage:
 *   import { mountBeforeYouBegin } from "./before-you-begin.js";
 *   mountBeforeYouBegin(document.getElementById("host"), {
 *     onStart: () => goToStep(1)
 *   });
 *
 * @license MIT
 */

export const DEFAULT_REQUIREMENTS = [
  {
    id: "cv",
    title: "A 2-page CV",
    detail: "PDF format, maximum 4 MB, ready to upload from this device.",
    confirm: "My CV is saved as a PDF, no more than 2 pages and under 4 MB"
  },
  {
    id: "background",
    title: "Your background",
    detail: "Maximum 300 words. Your training, your current role, and the kind of data " +
            "and analysis you work with.",
    confirm: "I have drafted my background, 300 words or fewer"
  },
  {
    id: "motivation",
    title: "Your motivation",
    detail: "Maximum 300 words. Why this workshop, what you would apply it to, and what " +
            "you would do with it afterwards.",
    confirm: "I have drafted my motivation, 300 words or fewer"
  }
];

const CSS = `
.byb{--b-gold:#EBBC40;--b-gold-tint:#fdf6e6;--b-black:#111010;--b-charcoal:#383838;
  --b-line:#e0deda;--b-light:#F3F3F3;--b-grey:#6f6d68;--b-bad:#96331f;--b-ok:#2f6b3f;
  --b-head:"Lato",-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;
  --b-body:"Nunito Sans",-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;
  font-family:var(--b-body);color:var(--b-black);line-height:1.6}
.byb h2{font-family:var(--b-head);font-size:24px;margin:0 0 6px}
.byb .b-lead{color:var(--b-grey);margin:0 0 18px}
.byb .b-callout{background:var(--b-gold-tint);border-left:4px solid var(--b-gold);
  padding:13px 15px;border-radius:0 8px 8px 0;font-size:14.5px;margin:0 0 20px}
.byb h3{font-family:var(--b-head);font-size:15px;margin:24px 0 10px;
  text-transform:uppercase;letter-spacing:.06em;color:var(--b-black);
  border-bottom:2px solid var(--b-gold);display:inline-block;padding-bottom:3px}
.byb .b-item{display:flex;gap:14px;padding:14px 0;border-bottom:1px solid var(--b-line)}
.byb .b-num{flex:0 0 30px;height:30px;border-radius:50%;background:var(--b-gold);
  color:var(--b-black);font-family:var(--b-head);font-weight:700;font-size:14px;
  display:flex;align-items:center;justify-content:center}
.byb .b-body{flex:1;min-width:0}
.byb .b-title{font-family:var(--b-head);font-weight:700;font-size:16px;margin:2px 0 3px}
.byb .b-detail{font-size:14.5px;color:var(--b-charcoal);margin:0}
.byb .b-confirms{margin:22px 0 0;padding:16px 18px;background:var(--b-light);
  border-radius:8px}
.byb .b-check{display:flex;gap:11px;align-items:flex-start;margin:0 0 11px;
  font-size:14.5px;cursor:pointer}
.byb .b-check:last-child{margin-bottom:0}
.byb .b-check input{margin:4px 0 0;width:17px;height:17px;accent-color:var(--b-charcoal);
  flex:0 0 auto;cursor:pointer}
.byb .b-check.b-missing{color:var(--b-bad);font-weight:600}
.byb .b-actions{margin-top:22px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.byb button{font-family:var(--b-head);font-weight:700;cursor:pointer;border-radius:8px;
  border:1px solid transparent;padding:11px 22px;font-size:15px}
.byb .b-start{background:var(--b-gold);color:var(--b-black)}
.byb .b-start:hover{background:#c99c26}
.byb .b-start[disabled]{background:#ded9cd;color:#8a8781;cursor:not-allowed}
.byb .b-ghost{background:#fff;color:var(--b-black);border-color:#cbc9c4}
.byb .b-ghost:hover{background:var(--b-light)}
.byb .b-err{color:var(--b-bad);font-size:13.5px;font-weight:700;margin-top:12px}
.byb .b-time{font-size:13.5px;color:var(--b-grey);margin-top:14px}
`;

function injectCss(){
  if (document.getElementById("byb-styles")) return;
  const s = document.createElement("style");
  s.id = "byb-styles";
  s.textContent = CSS;
  document.head.appendChild(s);
}

const esc = s => String(s ?? "").replace(/[&<>"']/g,
  c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));

/**
 * Render the preparation screen.
 * @param {HTMLElement} host
 * @param {object} [opts]
 * @param {Function} [opts.onStart]              Called when the applicant begins.
 * @param {Array}    [opts.requirements]         Override the list.
 * @param {boolean}  [opts.requireConfirmation=true]  Gate the start button on the tickboxes.
 * @param {string}   [opts.deadline]             e.g. "Friday 28 August 2026"
 * @param {string}   [opts.duration="about 15 minutes"]
 * @param {string}   [opts.costNote]             Funding statement, shown prominently.
 * @param {string}   [opts.startLabel="Start my application"]
 * @returns {{confirmed:Function, validate:Function}}
 */
export function mountBeforeYouBegin(host, opts = {}) {
  injectCss();
  const reqs = opts.requirements || DEFAULT_REQUIREMENTS;
  const gate = opts.requireConfirmation !== false;
  const duration = opts.duration || "about 15 minutes";

  host.classList.add("byb");
  host.innerHTML = `
    <h2>Before you begin</h2>
    <p class="b-lead">Please prepare the following before you start. The application takes
    ${esc(duration)} and includes a short timed section, so it is much easier if you have
    these ready.</p>

    ${opts.costNote ? `<div class="b-callout">${opts.costNote}</div>` : ""}

    <h3>Prepare these three things</h3>
    ${reqs.map((r, i) => `<div class="b-item">
      <div class="b-num" aria-hidden="true">${i + 1}</div>
      <div class="b-body">
        <p class="b-title">${esc(r.title)}</p>
        <p class="b-detail">${esc(r.detail)}</p>
      </div>
    </div>`).join("")}

    ${gate ? `<div class="b-confirms">
      ${reqs.map((r, i) => `<label class="b-check" data-c="${i}">
        <input type="checkbox" id="byb_${esc(r.id)}">
        <span>${esc(r.confirm)}</span>
      </label>`).join("")}
    </div>` : ""}

    <p class="b-time">You cannot save and return, so please set aside ${esc(duration)}
    in one sitting.${opts.deadline
      ? ` Applications close <strong>${esc(opts.deadline)}</strong>.` : ""}</p>

    <div class="b-actions">
      <button class="b-start" id="byb-start"${gate ? " disabled" : ""}>
        ${esc(opts.startLabel || "Start my application")}
      </button>
      <button class="b-ghost" id="byb-print">Print this list</button>
    </div>
    <div class="b-err" id="byb-err" hidden></div>`;

  const boxes = () => [...host.querySelectorAll('.b-confirms input[type=checkbox]')];
  const startBtn = host.querySelector("#byb-start");

  if (gate) {
    host.addEventListener("change", () => {
      const all = boxes().every(b => b.checked);
      startBtn.disabled = !all;
      if (all) host.querySelector("#byb-err").hidden = true;
      host.querySelectorAll(".b-check").forEach(l =>
        l.classList.toggle("b-missing", !l.querySelector("input").checked
          && !host.querySelector("#byb-err").hidden));
    });
  }

  const confirmed = () => {
    const out = {};
    reqs.forEach(r => {
      const b = host.querySelector(`#byb_${r.id}`);
      out[r.id] = b ? b.checked : true;
    });
    return out;
  };

  const validate = () => {
    if (!gate) return { ok: true };
    const unticked = boxes().filter(b => !b.checked);
    const err = host.querySelector("#byb-err");
    if (unticked.length) {
      err.hidden = false;
      err.textContent = "Please confirm all three items before starting.";
      host.querySelectorAll(".b-check").forEach(l =>
        l.classList.toggle("b-missing", !l.querySelector("input").checked));
      return { ok: false, message: err.textContent };
    }
    err.hidden = true;
    return { ok: true };
  };

  startBtn.onclick = () => {
    const r = validate();
    if (!r.ok) return;
    if (typeof opts.onStart === "function") opts.onStart(confirmed());
  };
  host.querySelector("#byb-print").onclick = () => window.print();

  return { confirmed, validate };
}
